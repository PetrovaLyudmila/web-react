export const Footer = () => {
    return (
        <div>All rights reserved &copy;</div>
    );
};